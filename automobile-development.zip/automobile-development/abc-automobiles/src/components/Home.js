import React from 'react';
import './Home.css';
function Home(){
    return(
<>



<div id="carouselExampleDark" class="carousel carousel-dark slide">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active" data-bs-interval="10000">
      <img src="https://www.bmwgroup.com/content/grpw/websites/bmwgroup_com/en/_jcr_content/main/multidownload/item_1720518012642/teaser_755575587.coreimg.82.1920.jpeg/1722411603010/com-templates-2560x896b.jpeg" class="d-block w-100" alt="..."/>
      <div class="carousel-caption d-none d-md-block">
        <h1 className='items'>BMW Group continues profitability course in a volatile environment.</h1>
        
      </div>
    </div>
    <div class="carousel-item" data-bs-interval="2000">
      <img src="https://www.bmwgroup.com/content/grpw/websites/bmwgroup_com/en/_jcr_content/main/multidownload/item_1721311750455/teaser_706607409.coreimg.82.1920.jpeg/1721311983955/2560x896-batteryproduction-header.jpeg" class="d-block w-100" alt="..."/>
      <div class="carousel-caption d-none d-md-block">
        <h1 className='items'>Think global – act local for local.
          <br/>
          Where the BMW Group will make its next generation of high-voltage batteries.
  
        </h1>
            </div>
    </div>
    <div class="carousel-item">
      <img src="https://www.bmwgroup.com/content/grpw/websites/bmwgroup_com/en/_jcr_content/main/multidownload/carouselstack/teaser_91433684.coreimg.82.1920.jpeg/1711010598878/neue-klasse-x-2560x896.jpeg" class="d-block w-100" alt="..."/>
      <div class="carousel-caption d-none d-md-block">
        <h1 className='items'>The BMW Vision Neue Klasse X.</h1>
        
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

<div className="hello">
<h2 className="pointer-style">The BMW Group at a glance.</h2>
<div className="container-md d-flex">
    

      <div className="card" style={{ width: '18rem' }}>
        <img 
          src="https://www.bmwgroup.com/content/grpw/websites/bmwgroup_com/en/_jcr_content/main/layoutcontainer_1610/columncontrol_copy_c/columncontrolparsys/poolteaser.coreimg.82.480.jpeg/1707217969663/720x480-unternehmen-bmw-group.jpeg" 
          className="card-img-top" 
          alt="Company 1"
        />
        <div className="card-body">
          <h4>COMPANY.</h4>
        </div>
      </div>

      <div className="card" style={{ width: '18rem' }}>
        <img 
          src="https://www.bmwgroup.com/content/grpw/websites/bmwgroup_com/en/_jcr_content/main/layoutcontainer_1610/columncontrol_copy_c/columncontrolparsys/poolteaser_copy.coreimg.82.480.png/1724148246944/neue-klasse-interior-720x480.png" 
          className="card-img-top" 
          alt="Company 2"
        />
        <div className="card-body">
        <h4>INNOVATION.</h4>
        </div>
      </div>

      <div className="card" style={{ width: '18rem' }}>
        <img 
          src="https://www.bmwgroup.com/content/grpw/websites/bmwgroup_com/en/_jcr_content/main/layoutcontainer_1610/columncontrol_copy_c/columncontrolparsys/poolteaser_copy_815219951.coreimg.82.480.jpeg/1721054436692/bmwgroup-nachhaltigkeit-720x480px.jpeg" 
          className="card-img-top" 
          alt="Company 3"
        />
        <div className="card-body">
        <h4>SUSTAINABILITY.</h4>
        </div>
      </div>

      <div className="card" style={{ width: '18rem' }}>
        <img 
          src="https://www.bmwgroup.com/content/grpw/websites/bmwgroup_com/en/_jcr_content/main/layoutcontainer_1610/columncontrol_copy_c/columncontrolparsys/poolteaser_copy_copy.coreimg.82.480.jpeg/1714995459714/720x480-investor-relations-crosslink-teaser-kennzahlen.jpeg" 
          className="card-img-top" 
          alt="Company 4"
        />
        <div className="card-body">
        <h4>INVESTOR RELATION.</h4>
        </div>
      </div>
    </div>
</div>

       <div className='hello2'>
       <h2 className='pointer-style2'>BE INSPIRED.</h2>
       <div className="container-md d-flex">

    <div className="card" style={{ width: '370px', position: 'relative' }}>
        <img src="https://www.bmwgroup.com/content/grpw/websites/bmwgroup_com/en/_jcr_content/main/layoutcontainer_copy/columncontrol/columncontrolparsys/teasertextimage_0_co.coreimg.82.852.png/1722407438094/bmw-key-visual-report-ohne-logo-720.png" 
          className="card-img-top" 
          alt="Company 4"
        />
        <div className="overlay">
            <h2>HALF-YEAR REPORT<br />TO 30 JUNE 2024.</h2>
            
        </div>
    </div>

    <div className="card" style={{ width: '370px', position: 'relative' }}>
        <img src="https://www.bmwgroup.com/content/grpw/websites/bmwgroup_com/en/_jcr_content/main/layoutcontainer_copy/columncontrol/columncontrolparsys/teasertextimage_0_co_2062421222.coreimg.82.852.jpeg/1721055315500/bmwgroup-nachhaltigkeit-720x720px.jpeg" 
          className="card-img-top" 
          alt="Company 4"
        />
        <div className="overlay">
            <h2>We make the BMW<br/> GROUP <br/>sustainable.</h2>
            
        </div>
    </div>

    <div className="card" style={{ width: '370px', position: 'relative' }}>
        <img src="https://www.bmwgroup.com/content/grpw/websites/bmwgroup_com/en/_jcr_content/main/layoutcontainer_copy/columncontrol/columncontrolparsys/teasertextimage_0_co_2146410633.coreimg.82.852.jpeg/1708072911936/ac24-website-720x720.jpeg" 
          className="card-img-top" 
          alt="Company 4"
        />
        <div className="overlay">
            <h2>BMW Group <br/>Annual<br/> Conference 2024.</h2>
            
        </div>
    </div>

</div>

</div>

<div className='hello3'>
    <h2 className='pointer-style3'>OUR CURRENT TOPICS.</h2>
     <div className="container-md d-flex">
        
          < img src="https://www.bmwgroup.com/content/dam/grpw/websites/bmwgroup_com/News/2024/1280x854_sonderschutzfahrzeuge_teaser.png" className='BMW-PHOTO'/>
          
          <h4 className='safety'>Company
|20-08-2024|<br/>
SAFETY IN MOTION – BMW <br/>PROTECTION VEHICLES AND <br/>SECURITY DRIVER TRAINING.</h4>
          </div>

    <div className='pointer-style3'></div>
     <div className="container-md d-flex">

     <div class="card" style={{ width: '370px', position: 'relative' }}>
  <img src="https://www.bmwgroup.com/content/dam/grpw/websites/bmwgroup_com/News/2024/1280x854_RadHub_News_Teaser.png" class="card-img-top" alt="..."/>
  <div class="card-body">
    <h5 class="card-title">Company |14-08-2024|
</h5>
    <h4 class="card-text">The World in 2050? – BMW rad°hub at London Climate Action Week.</h4>
  </div>
</div>

<div class="card" style={{ width: '370px', position: 'relative' }}>
  <img src="https://www.bmwgroup.com/content/dam/grpw/websites/bmwgroup_com/News/2024/1280x854_Automatisiertes_Fahren_News_Teaser.png" class="card-img-top" alt="..."/>
  <div class="card-body">
    <h5 class="card-title">Innovation |02-08-2024|.</h5>
    <h4 class="card-text">BMW Group sets new standards in Automated Driving.</h4>
    
  </div>
</div>

<div class="card" style={{ width: '370px', position: 'relative' }}>
  <img src="https://www.bmwgroup.com/content/dam/grpw/websites/bmwgroup_com/News/2024/1280x854_Batteryproduction_Teaser.png" class="card-img-top" alt="..."/>
  <div class="card-body">
    <h5 class="card-title">Electromobility |19-07-2024|.</h5>
    <h4 class="card-text">Think global – act local for local: Where the BMW Group will make its next generation of high-voltage batteries.</h4>
   
  </div>
</div>

    </div>

    <div className='pointer-style3'></div>
     <div className="container-md d-flex">
        
     <h3 className='pointer-style3'> <h5>Sustainability |03-07-2024|</h5> <br/> 
     Limestone replaces water to save resources in BMW paint shops.
     </h3>
     
     < img src="https://www.bmwgroup.com/content/dam/grpw/websites/bmwgroup_com/News/2024/1280x854_production-bmw-5-er.png" className='BMW-PHOTO'/>
     
    </div>

    <div className='pointer-style3'></div>
     <div className="container-md d-flex">
        
     <div class="card" style={{ width: '370px', position: 'relative' }}>
  <img src="https://www.bmwgroup.com/content/dam/grpw/websites/bmwgroup_com/News/2024/1280x854_Decarbonisation_Teaser_EN_V2.png" class="card-img-top" alt="..."/>
  <div class="card-body">
    <p>Sustainability |25-06-2024|</p>
    <h3 class="card-title">Driving decarbonisation in the supply chain.</h3>
    <p class="card-text">It takes a 360-degree approach to drive decarbonisation effectively across a supply chain – as BMW Group is showing.</p>
  </div>
</div>

      
<div class="card" style={{ width: '370px', position: 'relative' }}>
  <img src="https://www.bmwgroup.com/content/dam/grpw/websites/bmwgroup_com/News/2024/1280x854_Vorschau_Artcar.png" class="card-img-top" alt="..."/>
  <div class="card-body">
    <p>Company |21-05-2024|</p>
    <h3 class="card-title">20th BMW Art Car supports artists.</h3>
    <p class="card-text">The 20th BMW Art Car by Julie Mehretu cuts a dash at its world premiere. The artist joins forces with the BMW Group to launch a series of sponsorship projects for up-and-coming artists in Africa.
    </p>
  </div>
</div>

    
<div class="card" style={{ width: '370px', position: 'relative' }}>
  <img src="https://www.bmwgroup.com/content/dam/grpw/websites/bmwgroup_com/News/2024/Diversity_1280x854_V01.png" class="card-img-top" alt="..."/>
  <div class="card-body">
    <p>Company |17-05-2024|</p>
    <h3 class="card-title">Come as you are.</h3>
    <p class="card-text">International Day Against Homophobia and Transphobia on 17 May and the subsequent Pride Month in June shine a spotlight on the needs and concerns of the queer community.</p>
  </div>
</div>


    </div>

    <div className='pointer-style3'></div>
     <div className="container-md d-flex">
        
         
<div class="card" style={{ width: '370px', position: 'relative' }}>
  <img src="https://www.bmwgroup.com/content/dam/grpw/websites/bmwgroup_com/News/2024/1280x854-teaser-new-mini-aceman.png" class="card-img-top" alt="..."/>
  <div class="card-body">
    <p>Design |06-05-2024|</p>
    <h3 class="card-title">YOUNG, INDIVIDUAL, DIFFERENT: THE NEW ALL-ELECTRIC MINI ACEMAN.</h3>
    
  </div>
</div>

    
<div class="card" style={{ width: '370px', position: 'relative' }}>
  <img src="https://www.bmwgroup.com/content/dam/grpw/websites/bmwgroup_com/News/2024/1280x854_battery-trends-kurt.png" class="card-img-top" alt="..."/>
  <div class="card-body">
    <p>Innovation |30-04-2024|</p>
    <h3 class="card-title">“I think we’re moving in exactly the right direction” – battery expertise at the BMW Group.</h3>

 </div>
</div>

    
<div class="card" style={{ width: '370px', position: 'relative' }}>
  <img src="https://www.bmwgroup.com/content/dam/grpw/websites/bmwgroup_com/News/2024/Content_J05_1280x854px.jpg" class="card-img-top" alt="..."/>
  <div class="card-body">
    <p>Electromobility |24-04-2024|</p>
    <h3 class="card-title">The new MINI Aceman.</h3>
    <p class="card-text">The all-electric crossover model closes the gap between the MINI Cooper and the more grown MINI Countryman.</p>
  </div>
</div>

  
    </div>
   
    <button type="button" id="btn">READ MORE</button>
     

</div>
      

</>
    )
}
export default Home;
