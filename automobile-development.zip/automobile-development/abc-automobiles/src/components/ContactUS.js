import React from 'react';
import './ContactUS.css';

function ContactUS(){



  return(
        <>
        <div className="heading">
            <p>
                Offering up to $19,000 towards a lease or new vehicle purchase for Active Duty, Veterans, and Military Family Members. <u className='u'>Learn More here</u>
            </p>
        </div>


        <div className='ContactUS'>
        <h1 >ContactUS</h1>
        </div>

        <div className='feedback' >
            <div className='welcome'>
            <h2>We Welcome Your Feedback and Comments</h2>
            <p>Do you have questions or comments for us? We'd love to hear them! Fill out the form and we will get back to you as soon as possible.
         <br/>
          If you need help with any aspect of the buying  process, please don't hesitate to ask us. Our  customer service representatives will be happy to  assist you in any way. Whether through email, phone or in person, we're here to help you get the customer service you deserve.</p>
            </div>
            

   

          <div className='Links'>
            <div className='Links2'>
            <h3 >Related Links</h3>
            <p className='Links3'>About</p>
            <p className='Links3'> Directions</p>
            <p className='Links3'> Contact</p>
            <p className='Links3'> Parts Store</p>
            <p className='Links3'> Alternate Transportation Policy</p>
            </div>
            
          </div>



        </div>




        <div className="contact-us">
      <div className="form-container">
        <h2>Schedule your service</h2>
        <form>
          <div className="input-container">
            <input 
              type="text" 
              placeholder="Start with Phone or Email" 
              required 
            />
            <button type="submit">SEARCH</button>
          </div>
          <div className="google-signin">
            <button className="google-btn">
              <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAVdSURBVGhD7ZlrUFRlGMfPOcssH2waR0tFiMGckMEJnKAUNjBuJgqCFzInE8QmVG7qmDAruCJ3EVyIuEhyqSGM4bY3FmWKBUVrcLp9akKbpM+lgICVPG/voXdphffILnsW9wP/md8H5rzP8/yffW9nWWZRi1rUwgkUUk90ii2AI9x1OMANwT72T9jNjvGgd9gH8D73OyRw/XCcLUIKqQcJsw8hBeMKqZIm2MuOokAGoQAzwWMhhh2GZMkVkDNOJN3CC3IYZ0jEn3woA1SjFsDnwDPVB7nMSpJ+YQQfST6GLcwkzZQ1wFZ2Ei+7ElLGdkLnmVUQz92hmRATiOMG8ZJdSsqKKzgnXQd78KalFLYFeP+MiN4MfxpBNPsXraCtwPtPS8qLI1TNvIA/nQWbCR7Rm+AFB7lfacWeylv/LQ04xN3Bp9EA+pC7DXHsXf64RZsp402wTRP4dKIVE4LfQ/hOqYZixpmkmCU4zayFFEkVXqoTs+Jt0kQB4wLbWLOOWHibwcempAI1MxISPqfwRnaYaojcQzZpghfUOFxG4SzVuCn49WMcMh1kJMxiwWmHQJQqqSd/iivUwywFg+MI6pQiFM9RG+DhlwdeKi+RMPsT9DomoV5HNIUBk+swtYGfaCIMv1ZkOfiREPsUno1vpxsx8gWenaj/lxq/J8hw+xT0L1mBG4FZjfBcxSRyCHay45Zs7GciZJDGUJswAT6TppDhZklRlbZfDLIqT0YVXUpaU1qa/DxJLSw8G3k080bw/vkHbjLLyHCz5HTqJyQmHxQrb5DUwsJmm2eaNwUM0rmTzBDNjDXsKqy9R1ILC3qlfbQGjOAZaSRDzRbNjDVsyW5+QFILCxv9ntaAEfy8mAw1WzQz1hCYpRonqYWFjX5Ha8CIPTQSYF4j9r+0QrNb5l5a2Kzdb/bdBXVDJLWw8CeeS2vACH7+zI/fg8Vl/SS1sOa6EH/+aiWq13tdJMPNEu1yEyL+gvIWzbwpGZXp+SS1sKDvuReFXlHU19xRdMcOdFgVOt6MxH9FUSgUHH8i0cwbcUn7AVVWJriRkKcL74NvTBuYMCxBhbqNKKI9ehql1reGDBdNx8uyL9PMmxKc0zJChs8tvA8SjU0Mfb0cHVaHPtEEz7vt26C50/NNEmK15BXyTR6nrwPNvCmJpQVXSMjcIl+shg3da9CejohZTRhJUIVN1Lavt/qLVX5lqpssSzNBM26Ku7wfKusPCP4/gKov9Z5tNPMz4Ztp7J7/zJyvOSbzP6t9RDM+k7gL5bdImPnS97o6xaq2PqaZn8k+VfikUu9TbckBoEAMd1Hv+2lsa/TjsLwmqnFTPOV9k9mfnJjf7Fd1eitpxoU4qgoZV3b61nR1rRUsWNfjuaq006c2QR06boyLbt2FYkrKqA0YSVQWVpEU89NZjWzQ1Kw5RLVHoSR18GimRnY3R+t3O1vjN5ChlQ0mqUNG+We0mMi2nSiuKhOtTvtxVhNR+Q2/ETvz180ul2XJ2BStuC04VJ+I3NIHppvwz9KNpdTkivO7SV2Xj8cRVcgjWmFbENsYh17N7EG+Z679nVZ2zpvYEEdt3R7uSeqgh7TCtuBEy477GeUZ60l5cdV69eUVWVp/i/eMpZzRyn5pa/NYTsraTlVd3sr3OsInaSasYT/OWaHbYPuf3kyl0bziXKR7wxDTHgE0U5awt3075Os29XV0rFtN0i+8GtSeruX61z4/pgoajqSYFCISH8Mp6qCREt3rTa348iXp7ENNOi/3S3qvnHzdxj65NuDeSfXmP46qgx/ii3IsRR18P10TOJSn8btRod9Q0IDHkrBFLWpRNhfD/AvExD6LqAHXuwAAAABJRU5ErkJggg==" alt="Google sign Button" />
              Sign in with Google
            </button>
          </div>
          <div className="signin-options">
            <span>Have an account? <a href="/signin">Sign in</a></span>
          </div>
        </form>
      </div>
    </div>


     

    <div className="container-xxl">
  <span className="title">Select a Series</span> 
  <span className="series">X1</span> | 
  <span className="series">X3</span> | 
  <span className="series">X4</span> | 
  <span className="series">X5</span> | 
  <span className="series">X6</span> | 
  <span className="series">X7</span> | 
  <span className="series">M</span> | 
  <span className="series">2</span> | 
  <span className="series">3</span> | 
  <span className="series">4</span> | 
  <span className="series">5</span> | 
  <span className="series">7</span> | 
  <span className="series">8</span> | 
  <span className="series">Z4</span> | 
  <span className="series">i4</span> | 
  <span className="series">i5</span> | 
  <span className="series">i7</span> | 
  <span className="series">iX</span> | 
  <span className="series">XM</span>
</div>



        </>
    )
}
export default ContactUS;