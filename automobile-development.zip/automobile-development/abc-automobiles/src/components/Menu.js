import { Link } from "react-router-dom";
import "./Menu.css"; // Import your CSS file

function Menu() {
  return (
    <>
      <nav className="navbar">
        <div className="container-fluid d-flex justify-content-between align-items-center">
          <a className="navbar-brand d-flex" href="#">
            <img
              src="https://www.bmwgroup.com/content/dam/grpw/websites/bmwgroup_com/logo/svg/Logo_BMW_GROUP.svg"
              alt="Logo"
              width="61.33"
              height="32"
              className="d-inline-block align-text-top"
            />
            <img
              src="https://www.bmwgroup.com/content/dam/grpw/websites/bmwgroup_com/logo/svg/Logo_BMW.svg"
              alt="Logo"
              width="64"
              height="32"
              className="d-inline-block align-text-top"
            />
            <img
              src="https://www.bmwgroup.com/content/dam/grpw/websites/bmwgroup_com/logo/svg/Logo_MINI.svg"
              alt="Logo"
              width="62.08"
              height="32"
              className="d-inline-block align-text-top"
            />
            <img
              src="https://www.bmwgroup.com/content/dam/grpw/websites/bmwgroup_com/logo/svg/Logo_Rolls-Royce.svg"
              alt="Logo"
              width="80"
              height="32"
              className="d-inline-block align-text-top"
            />
          </a>
          <nav className="navbar navbar-expand-lg bg-body-tertiary">
            <div className="container-fluid">
              <a className="navbar-brand" href="#">
                
              </a>
              <button
                className="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarNav"
                aria-controls="navbarNav"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon"></span>
              </button>
              <div className="collapse navbar-collapse" id="navbarNav">
                <ul className="navbar-nav">
                  <li className="nav-item">
                    <Link className="nav-link active" aria-current="page" to="/">
                      Home
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link className="nav-link" to="/Vehicles">
                      Vehicles
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link className="nav-link" to="/Services">
                      Services
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link className="nav-link" to="/CarRecommendation">
                      CarRecommendation
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link className="nav-link" to="/ContactUS">
                      ContactUS
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
        </div>
      </nav>
    </>
  );
}

export default Menu;
