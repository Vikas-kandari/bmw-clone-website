import React from 'react';
import { Container, Row, Col, Button, Carousel } from 'react-bootstrap';
import './CarRecommendation.css'; // Import custom CSS

const CarRecommendation = () => {
    const carouselItems = [
        "https://www.bmw-infinitycars-delhi.in/sites/default/files/2024-05/3GL_0.jpg",
        "https://www.bmw-infinitycars-delhi.in/sites/default/files/2022-12/M340I-desktop-banner_3.jpg",
        "https://www.bmw-infinitycars-delhi.in/sites/default/files/2024-07/1680x756%20%281%29%20%281%29.jpg",
        "https://www.bmw-infinitycars-delhi.in/sites/default/files/2024-05/X1.jpg",
        "https://www.bmw-infinitycars-delhi.in/sites/default/files/2024-05/X3%202_0.jpg",
        "https://www.bmw-infinitycars-delhi.in/sites/default/files/2023-01/1680x756_3.jpg",
        "https://www.bmw-infinitycars-delhi.in/sites/default/files/2024-04/1680x756_0.jpg",
        "https://www.bmw-infinitycars-delhi.in/sites/default/files/2024-03/1680x756_WoC%202.jpg",
        "https://www.bmw-infinitycars-delhi.in/sites/default/files/2023-01/1680x756_5.jpeg",
        "https://www.bmw-infinitycars-delhi.in/sites/default/files/2024-08/iX1_0-1680.jpg",
        "https://www.bmw-infinitycars-delhi.in/sites/default/files/2023-01/1680x756.jpeg",
        "https://www.bmw-infinitycars-delhi.in/sites/default/files/2023-01/1680x756.jpeg",
        "https://www.bmw-infinitycars-delhi.in/sites/default/files/2022-09/M8_1680x756%20%281%29.jpg",
        "https://www.bmw-infinitycars-delhi.in/sites/default/files/2023-05/desktop_banner_modi.png"
    ];

    return (
        <Container fluid className="p-0" style={{ backgroundColor: '#333', color: '#fff', paddingTop: '30px' }}>
            <Row className="mb-4">
                <Col md={12} className="carousel-container">
                    <Carousel className="carousel-full">
                        {carouselItems.map((src, index) => (
                            <Carousel.Item key={index}>
                                <img
                                    src={src}
                                    alt={`Carousel image ${index + 1}`}
                                    className="d-block w-100"
                                />
                                <Carousel.Caption className="carousel-caption-left">
                                    <h3>The BMW 2 Series Gran Coupé</h3>
                                </Carousel.Caption>
                                <Carousel.Caption className="carousel-caption-right">
                                    <ul>
                                        <li>Pay just ₹49,999/Month*</li>
                                        <li>Now at an interest rate of 7.75%</li>
                                        <li>Includes registration charges</li>
                                        <li>Includes 4 years service charges</li>
                                        <li>Includes roadside assistance</li>
                                        <li>Corporate benefits with BMW Corporate Advantage Programme</li>
                                        <li>Assured buyback</li>
                                    </ul>
                                </Carousel.Caption>
                            </Carousel.Item>
                        ))}
                    </Carousel>
                    <Button variant="light" size="lg" className="carousel-button">Book an Experience</Button>
                </Col>
            </Row>
        </Container>
    );
};

export default CarRecommendation;
