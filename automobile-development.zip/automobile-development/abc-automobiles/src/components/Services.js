import React from 'react';
import './Services.css';
function Services(){
    return(
        <>
        
        <div className='girl'>
        <img src="https://www.bmw.in/content/dam/bmw/marketIN/bmw_in/Images/Topics/relax-we-care/master-banner-desktop.jpg/jcr:content/renditions/cq5dam.resized.img.1680.large.time1697180993760.jpg" class="img-fluid" alt="..."/>
        <div className="overlay-text">RELAX. WE CARE.
            <h2>#WHAT EVER HAPPENS</h2>
        </div>
        </div>
       <br/>
       
<div className="container">
    <h1 >
    WELCOME TO THE WORLD OF BMW SERVICE.
    </h1>
    <h3>
    FOR YOUR SHEER DRIVING PLEASURE.
    </h3>
    <br/>
    <br/>
  

   <div className="container-md d-flex" >

           <img src="https://www.bmw.in/content/dam/bmw/marketIN/bmw_in/Images/Topics/relax-we-care/high/online-appointment-system.jpg" width={'560px'}/>
        <div className="container">

           <h3>ONLINE APPOINTMENT SYSTEM</h3>
           <p>Easily schedule your BMW service from anywhere, at any time, and at any authorised BMW dealership. Enjoy the complete freedom of choosing your date and time, desired service and even your preferred staff member. You also have the option to modify the appointment later and booking an online appointment without registering.</p>

             <div class="d-grid gap-2 col-7 mx-auto">
             <button class="btn btn-primary" type="button">Know More</button>
  
             </div>

       </div>
           
    </div>
            
</div>


<div className="container">
        
            
            <h1 >
            JOY REWARDS
            </h1>
          
            <div className="container-md d-flex" >
            
           <p>
           When you are part of the family of one of the world’s leading automotive brands, it has its benefits. With regular savings on service and maintenance, enjoy rewards with every passing year of ownership. Not only do you save up to 30% on the service of models older than five years, you also get genuine BMW service by authorised dealers that increases the longevity of the vehicle.

           <div class="d-grid gap-2 col-7 mx-auto">
           <button class="btn btn-primary" type="button">Know More</button>
           </div>

           </p>

           <img src="https://www.bmw.in/content/dam/bmw/marketIN/bmw_in/Images/Topics/relax-we-care/high/joy-rewards.jpg" width={'560px'}/>
    

    </div>
           
            </div>
            
                
            <div className="container">
    
   <div className="container-md d-flex" >

           <img src="https://www.bmw.in/content/dam/bmw/marketIN/bmw_in/Images/Topics/relax-we-care/high/online-appointment-system.jpg" width={'560px'}/>
        <div className="container">

           <h1>SMART VIDEO</h1>
           <p>We ensure transparency meets personalisation, when it comes to serving your BMW. To simplify the technical aspects of the service of your BMW, we send you a video that explains the service or repair requirements, straight to your device. You can then review it and give approvals online from the comfort of your home.</p>

             <div class="d-grid gap-2 col-7 mx-auto">
             <button class="btn btn-primary" type="button">Know More</button>
  
             </div>

       </div>
           
    </div>
            
</div>

        
             <div className="container">
        
        <br/>
        
        <div className="container-md d-flex" >

       <p>
         
       <h1 >
        ConnectedDrive.
        </h1>
       Get support even before you know you need it. BMW ConnectedDrive uses an array of sensors to proactively detect the condition of your BMW in real-time – malfunctions, impending issues or service requirement. It then sends the relevant information to you via the My BMW App, in-car notification or email. So that you never have to worry about your BMW, and simply enjoy life.

       <div class="d-grid gap-2 col-7 mx-auto">
       <button class="btn btn-primary" type="button">Know More</button>
       </div>

       </p>

       <img src="https://www.bmw.in/content/dam/bmw/marketIN/bmw_in/Images/Topics/relax-we-care/high/connected-drive.jpg" width={'560px'}/>


</div>
       
        </div>
        
      <div className="container">
    
    
    <br/>
   <div className="container-md d-flex" >

           <img src="https://www.bmw.in/content/dam/bmw/marketIN/bmw_in/Images/Topics/relax-we-care/high/bmw-service-inclusive.jpg" width={'560px'}/>
        <div className="container">

           <h1>SERVICE INCLUSIVE.</h1>
           <br/>
           <p>Enjoy uninterrupted peace of mind. With Service Inclusive, there's no need to expend a single thought on maintenance, inspections, or wear and tear expenses. A one-off fixed payment encompasses a comprehensive range of services provided by BMW Service to enhance performance and ensure long-lasting quality.</p>
           <br/>

             <div class="d-grid gap-2 col-7 mx-auto">
             <button class="btn btn-primary" type="button">Know More</button>
  
             </div>

       </div>
           
    </div>
            
</div>

        
<div className="container">
        
        <br/>
        
        <div className="container-md d-flex" >

       <p>
         
       <h1 >
       ORIGINAL BMW ENGINE OIL.
        </h1>
        <br/>
        
        Unleash the full potential of your BMW by protecting it with the Original BMW Engine Oils that are optimised to perfectly suit the engine of your BMW. They contribute to full power delivery with high efficiency as they help to protect the engine against wear and corrosion. This helps to keep the engine clean and to increase its service life. Sheer Driving Pleasure is always yours when you give your BMW the best.
        <br/>
        <br/>

       <div class="d-grid gap-2 col-7 mx-auto">
       <button class="btn btn-primary" type="button">Know More</button>
       </div>

       </p>

       <img src="https://www.bmw.in/content/dam/bmw/marketIN/bmw_in/Images/Topics/relax-we-care/high/engine-oil.jpg" width={'560px'}/>


</div>
     <br/>
      <p>We care for your BMW, so that you can focus on what matters the most – your Sheer Driving Pleasure. Avail these exclusive services at any BMW authorised dealership. So whatever happens, just relax.</p> 
      <br/>
        </div>
        

        </>
    )
}
export default Services;