import 'bootstrap/dist/css/bootstrap.min.css';
import Menu from "./components/Menu";
import Home from "./components/Home";
import Vehicles from "./components/Vehicles";
import CarRecommendation from "./components/CarRecommendation";
import Services from "./components/Services";
import ContactUS from "./components/ContactUS";
import Addvehicle from "./components/Addvehicle";
import UpdateVehicle from "./components/UpdateVehicle";
import {Routes , Route }from 'react-router-dom';
import Footer from "./components/Footer";
function App(){
  return(
    <>
   <Menu/>
   
   <Routes>
   <Route path="/" element={<Home/>}/>
   <Route path="/Vehicles" element={<Vehicles/>}/>
    <Route path="/add-vehicles" element={<Addvehicle/>}/>
    <Route path="/update-vehicle/:id" element={<UpdateVehicle/>}/>
   <Route path="/CarRecommendation" element={<CarRecommendation/>}/>
   <Route path="/Services" element={<Services/>}/>
   <Route path="/ContactUS" element={<ContactUS/>}/>
   </Routes>

   <Footer/>
    </>
  )
}

export default App;
//to start project run cd abc-automobiles and then npm start
//also start json server simultaneously , run json-server --watch db.json --port 5000
//note: {db.json is a dummy data base file}